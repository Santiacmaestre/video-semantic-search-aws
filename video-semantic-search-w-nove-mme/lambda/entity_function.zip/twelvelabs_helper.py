"""Helper module for 12Labs SaaS API calls."""
import json
import http.client
import time


def twelvelabs_request(api_key, method, path, body=None, content_type='application/json'):
    """Make a request to 12Labs API. Returns (status, data)."""
    conn = http.client.HTTPSConnection('api.twelvelabs.io', timeout=30)
    headers = {'x-api-key': api_key}
    
    if body and content_type == 'application/json':
        headers['Content-Type'] = 'application/json'
        conn.request(method, f'/v1.3{path}', body=json.dumps(body).encode(), headers=headers)
    elif body:
        headers['Content-Type'] = content_type
        conn.request(method, f'/v1.3{path}', body=body, headers=headers)
    else:
        conn.request(method, f'/v1.3{path}', headers=headers)
    
    resp = conn.getresponse()
    resp_body = resp.read().decode()
    conn.close()
    
    try:
        data = json.loads(resp_body)
    except:
        data = {'raw': resp_body}
    
    return resp.status, data


def upload_asset_from_url(api_key, image_url):
    """Upload an image asset to 12Labs from a URL. Returns asset_id."""
    boundary = f'----Boundary{int(time.time()*1000)}'
    parts = [
        f'--{boundary}\r\nContent-Disposition: form-data; name="method"\r\n\r\nurl',
        f'--{boundary}\r\nContent-Disposition: form-data; name="url"\r\n\r\n{image_url}',
    ]
    body = '\r\n'.join(parts) + f'\r\n--{boundary}--\r\n'
    
    status, data = twelvelabs_request(
        api_key, 'POST', '/assets',
        body=body.encode(),
        content_type=f'multipart/form-data; boundary={boundary}'
    )
    
    if status in (200, 201):
        return data.get('_id')
    print(f"12Labs upload asset failed: {status} {data}")
    return None


def create_entity_collection(api_key, name):
    """Create an entity collection. Returns collection_id."""
    status, data = twelvelabs_request(api_key, 'POST', '/entity-collections', {'name': name})
    if status in (200, 201):
        return data.get('_id')
    print(f"12Labs create collection failed: {status} {data}")
    return None


def list_entity_collections(api_key):
    """List entity collections. Returns list."""
    status, data = twelvelabs_request(api_key, 'GET', '/entity-collections')
    if status == 200:
        return data.get('data', [])
    return []


def create_entity(api_key, collection_id, name, asset_ids):
    """Create an entity in a collection. Returns entity_id."""
    status, data = twelvelabs_request(
        api_key, 'POST',
        f'/entity-collections/{collection_id}/entities',
        {'name': name, 'asset_ids': asset_ids}
    )
    if status in (200, 201):
        return data.get('_id')
    print(f"12Labs create entity failed: {status} {data}")
    return None


def delete_entity(api_key, collection_id, entity_id):
    """Delete an entity from a collection."""
    status, data = twelvelabs_request(
        api_key, 'DELETE',
        f'/entity-collections/{collection_id}/entities/{entity_id}'
    )
    return status in (200, 204)


def get_or_create_collection(api_key, project_name):
    """Get existing collection for project or use default."""
    collections = list_entity_collections(api_key)
    # Try to find one matching project name
    for c in collections:
        if c.get('name') == project_name:
            return c.get('_id')
    # Use first available collection (default)
    if collections:
        return collections[0].get('_id')
    # Try to create one
    return create_entity_collection(api_key, project_name)

"""Bedrock embedding generation module for Marengo 3.0 model."""
import boto3
import json
import time
import os
from typing import List, Dict
try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = lambda: None


bedrock_client = boto3.client('bedrock-runtime', region_name=os.getenv('AWS_REGION'))
s3_client = boto3.client('s3', region_name=os.getenv('AWS_REGION'))

MARENGO_MODEL_ID = os.getenv('MARENGO_MODEL_ID')
S3_VIDEO_BUCKET = os.getenv('S3_VIDEO_BUCKET')
AWS_ACCOUNT_ID = os.getenv('AWS_ACCOUNT_ID')


def generate_video_embeddings(video_s3_uri: str) -> List[Dict]:
    """Generate embeddings for video using Marengo 3.0 with dynamic segmentation.
    
    Returns list of segments with 3 embeddings each (visual, audio, transcription).
    """
    output_prefix = f'embeddings/{video_s3_uri.split("/")[-1]}/{int(time.time())}'
    
    model_input = {
        "inputType": "video",
        "video": {
            "mediaSource": {
                "s3Location": {
                    "uri": video_s3_uri,
                    "bucketOwner": AWS_ACCOUNT_ID
                }
            },
            "segmentation": {
                "method": "dynamic",
                "dynamic": {
                    "minDurationSec": 4
                }
            },
            "embeddingOption": ["visual", "audio", "transcription"],
            "embeddingScope": ["clip"]
        }
    }
    
    response = bedrock_client.start_async_invoke(
        modelId=MARENGO_MODEL_ID,
        modelInput=model_input,
        outputDataConfig={
            "s3OutputDataConfig": {
                "s3Uri": f's3://{S3_VIDEO_BUCKET}/{output_prefix}',
                "bucketOwner": AWS_ACCOUNT_ID
            }
        }
    )
    
    invocation_arn = response["invocationArn"]
    print(f"Started async embedding generation: {invocation_arn}")
    
    # Poll for completion
    max_retries = 60
    retry_count = 0
    while retry_count < max_retries:
        status_response = bedrock_client.get_async_invoke(invocationArn=invocation_arn)
        status = status_response['status']
        
        if status == "Completed":
            print("Embedding generation completed")
            break
        elif status == "Failed":
            raise Exception(f"Embedding generation failed: {status_response.get('failureMessage', 'Unknown error')}")
        
        time.sleep(5)
        retry_count += 1
    
    if retry_count >= max_retries:
        raise Exception("Embedding generation timed out")
    
    # Retrieve embeddings from S3
    response = s3_client.list_objects_v2(Bucket=S3_VIDEO_BUCKET, Prefix=output_prefix)
    output_file = None
    for obj in response.get('Contents', []):
        if obj['Key'].endswith('output.json'):
            output_file = obj['Key']
            break
    
    if not output_file:
        raise Exception("No embedding output found")
    
    result = s3_client.get_object(Bucket=S3_VIDEO_BUCKET, Key=output_file)
    data = json.loads(result['Body'].read())
    
    # Parse embeddings - group by segment
    segments = {}
    for item in data.get('data', []):
        embedding = item['embedding']
        start_sec = item.get('startSec', 0)
        end_sec = item.get('endSec', 0)
        embedding_option = item.get('embeddingOption', [])
        
        # Determine modality
        if 'visual' in embedding_option:
            modality = 'visual'
        elif 'audio' in embedding_option:
            modality = 'audio'
        elif 'transcription' in embedding_option:
            modality = 'transcription'
        else:
            continue
        
        # Group by start time (segment identifier)
        seg_key = f"{start_sec}_{end_sec}"
        if seg_key not in segments:
            segments[seg_key] = {
                'start_sec': start_sec,
                'end_sec': end_sec,
                'visual_emb': None,
                'audio_emb': None,
                'transcription_emb': None
            }
        
        segments[seg_key][f'{modality}_emb'] = embedding
    
    # Convert to list with segment indices
    result_segments = []
    for idx, (_, seg_data) in enumerate(sorted(segments.items())):
        seg_data['segment_index'] = idx
        result_segments.append(seg_data)
    
    print(f"Generated {len(result_segments)} segments with 3 embeddings each")
    return result_segments


def generate_text_embedding(query_text: str) -> List[float]:
    """Generate embedding for text query using Marengo 3.0 (synchronous)."""
    model_input = {
        "inputType": "text",
        "text": {
            "inputText": query_text
        }
    }
    
    response = bedrock_client.invoke_model(
        modelId=MARENGO_MODEL_ID,
        body=json.dumps(model_input)
    )
    
    result = json.loads(response['body'].read())
    embedding = result['data'][0]['embedding']
    
    print(f"Generated text embedding: {len(embedding)} dimensions")
    return embedding


def generate_face_embedding(face_crop_s3_uri: str) -> List[float]:
    """Generate Marengo embedding for face crop image (512-dim)."""
    bucket, key = face_crop_s3_uri.replace('s3://', '').split('/', 1)
    
    # Download face crop
    response = s3_client.get_object(Bucket=bucket, Key=key)
    image_bytes = response['Body'].read()
    
    # Encode to base64
    import base64
    image_base64 = base64.b64encode(image_bytes).decode('utf-8')
    
    # Generate embedding
    model_input = {
        "inputType": "image",
        "image": {
            "mediaSource": {
                "base64String": image_base64
            }
        }
    }
    
    response = bedrock_client.invoke_model(
        modelId=MARENGO_MODEL_ID,
        body=json.dumps(model_input)
    )
    
    result = json.loads(response['body'].read())
    embedding = result['data'][0]['embedding']
    
    print(f"Generated face embedding: {len(embedding)} dimensions")
    return embedding

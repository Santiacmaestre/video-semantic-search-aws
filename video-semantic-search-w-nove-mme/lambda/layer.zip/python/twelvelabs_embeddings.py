"""TwelveLabs Marengo 3.0 embeddings via Amazon Bedrock (512d)."""
import boto3
import json
import os
import time
from typing import List, Dict

aws_region = os.getenv('AWS_REGION', 'us-east-1')
bedrock = boto3.client('bedrock-runtime', region_name=aws_region)
s3_client = boto3.client('s3', region_name=aws_region)

MARENGO_MODEL_ID = 'twelvelabs.marengo-embed-3-0-v1:0'
DIMENSION = 512


def generate_text_embedding(text: str) -> List[float]:
    """Generate text embedding using Marengo 3.0 sync API (512d)."""
    response = bedrock.invoke_model(
        modelId=MARENGO_MODEL_ID,
        body=json.dumps({'inputType': 'text', 'text': {'inputText': text}}),
    )
    result = json.loads(response['body'].read())
    return result['data'][0]['embedding']


def generate_image_embedding(s3_uri: str) -> List[float]:
    """Generate image embedding using Marengo 3.0 sync API (512d).
    Downloads from S3 and sends base64 inline (mirrors Nova pattern)."""
    import base64
    bucket = s3_uri.replace('s3://', '').split('/')[0]
    key = '/'.join(s3_uri.replace('s3://', '').split('/')[1:])
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    image_b64 = base64.b64encode(obj['Body'].read()).decode('utf-8')

    response = bedrock.invoke_model(
        modelId=MARENGO_MODEL_ID,
        body=json.dumps({
            'inputType': 'image',
            'image': {'mediaSource': {'base64String': image_b64}},
        }),
    )
    result = json.loads(response['body'].read())
    return result['data'][0]['embedding']


def generate_video_embeddings(s3_uri: str, account_id: str) -> List[Dict]:
    """Generate visual+audio+transcription clip embeddings via Marengo 3.0 async API.

    Returns list of dicts: {segment_index, start_sec, end_sec,
    visual_emb, audio_emb, transcription_emb}.
    """
    output_bucket = os.getenv('S3_VIDEO_BUCKET', '')

    response = bedrock.start_async_invoke(
        modelId=MARENGO_MODEL_ID,
        modelInput={
            'inputType': 'video',
            'video': {
                'mediaSource': {
                    's3Location': {'uri': s3_uri, 'bucketOwner': account_id}
                },
                'embeddingOption': ['visual', 'audio', 'transcription'],
                'embeddingScope': ['clip'],
                'segmentation': {'method': 'dynamic', 'dynamic': {'minDurationSec': 4}},
            },
        },
        outputDataConfig={'s3OutputDataConfig': {
            's3Uri': f's3://{output_bucket}/marengo-embeddings/',
            'bucketOwner': account_id,
        }},
    )
    invocation_arn = response['invocationArn']
    print(f"Marengo async started: {invocation_arn}")

    while True:
        status_resp = bedrock.get_async_invoke(invocationArn=invocation_arn)
        status = status_resp['status']
        if status == 'Completed':
            break
        elif status == 'Failed':
            raise Exception(f"Marengo failed: {status_resp.get('failureMessage', 'Unknown')}")
        time.sleep(5)

    # Read output from S3
    output_uri = status_resp['outputDataConfig']['s3OutputDataConfig']['s3Uri']
    bucket = output_uri.replace('s3://', '').split('/')[0]
    prefix = '/'.join(output_uri.replace('s3://', '').split('/')[1:])
    output_key = f"{prefix}output.json" if prefix.endswith('/') else f"{prefix}/output.json"

    obj = s3_client.get_object(Bucket=bucket, Key=output_key)
    data = json.loads(obj['Body'].read())

    # Group clip embeddings by segment time range
    segments_map = {}
    for emb in data.get('data', []):
        if emb.get('embeddingScope') != 'clip':
            continue
        key = (emb.get('startSec', 0), emb.get('endSec', 0))
        if key not in segments_map:
            segments_map[key] = {'start_sec': key[0], 'end_sec': key[1]}
        option = emb.get('embeddingOption', '')
        if option in ('visual', 'audio', 'transcription'):
            segments_map[key][f'{option}_emb'] = emb['embedding']

    sorted_segs = sorted(segments_map.values(), key=lambda s: s['start_sec'])
    for i, seg in enumerate(sorted_segs):
        seg['segment_index'] = i

    print(f"Generated {len(sorted_segs)} Marengo segments (visual+audio+transcription)")
    return sorted_segs

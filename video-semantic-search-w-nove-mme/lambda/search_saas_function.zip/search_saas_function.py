"""Lambda function for 12Labs SaaS search API proxy."""
import json
import os
import time
import boto3
import http.client

dynamodb = boto3.resource('dynamodb')
PROJECTS_TABLE = os.environ['PROJECTS_TABLE']
VIDEOS_TABLE = os.environ.get('VIDEOS_TABLE', 'video-search-videos')

CORS = {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}


def respond(status, body):
    return {'statusCode': status, 'headers': CORS, 'body': json.dumps(body)}


def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        query = body.get('query', '')
        project_id = body.get('project_id', '')

        if not query or not project_id:
            return respond(400, {'error': 'query and project_id required'})

        table = dynamodb.Table(PROJECTS_TABLE)
        project = table.get_item(Key={'project_id': project_id}).get('Item')
        if not project:
            return respond(404, {'error': 'Project not found'})

        api_key = project.get('twelvelabs_api_key', '')
        index_id = project.get('twelvelabs_index_id', '')
        if not api_key or not index_id:
            return respond(400, {'error': '12Labs not configured'})

        start_time = time.time()

        # Resolve entity references (@name → <@twelvelabs_entity_id>)
        search_query = query
        if '@' in query:
            import re
            entities_table = dynamodb.Table(os.environ.get('ENTITIES_TABLE', 'video-search-entities'))
            for match in re.findall(r'@(\w+)', query):
                # Find entity by name
                resp = entities_table.scan(
                    FilterExpression='contains(#n, :name) AND project_id = :pid',
                    ExpressionAttributeNames={'#n': 'name'},
                    ExpressionAttributeValues={':name': match, ':pid': project_id}
                )
                for ent in resp.get('Items', []):
                    tl_eid = ent.get('twelvelabs_entity_id')
                    if tl_eid:
                        search_query = search_query.replace(f'@{match}', f'<@{tl_eid}>')
                        print(f"Resolved @{match} → <@{tl_eid}>")
                        break

        # Call 12Labs search API (multipart/form-data)
        boundary = f'----Boundary{int(time.time()*1000)}'
        fields = [
            ('index_id', index_id),
            ('query_text', search_query),
            ('search_options', 'visual'),
            ('search_options', 'audio'),
            ('threshold', 'low'),
            ('page_limit', '12')
        ]
        parts = []
        for name, value in fields:
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}')
        body_data = '\r\n'.join(parts) + f'\r\n--{boundary}--\r\n'

        conn = http.client.HTTPSConnection('api.twelvelabs.io', timeout=30)
        conn.request('POST', '/v1.3/search', body=body_data.encode('utf-8'), headers={
            'x-api-key': api_key,
            'Content-Type': f'multipart/form-data; boundary={boundary}'
        })
        resp = conn.getresponse()
        resp_body = resp.read().decode()
        conn.close()

        print(f"12Labs status: {resp.status}, response length: {len(resp_body)}")

        data = json.loads(resp_body)
        latency_ms = int((time.time() - start_time) * 1000)

        if resp.status != 200:
            return respond(200, {
                'results': [], 'total': 0, 'latency_ms': latency_ms,
                'error': data.get('message', f'12Labs error: {resp.status}')
            })

        # Build 12Labs video_id → our video mapping
        # Query 12Labs to get video list with metadata
        videos_table = dynamodb.Table(VIDEOS_TABLE)
        vid_resp = videos_table.scan(
            FilterExpression='project_id = :pid',
            ExpressionAttributeValues={':pid': project_id},
            ProjectionExpression='video_id, filename, twelvelabs_task_id'
        )
        our_videos = vid_resp.get('Items', [])
        
        # Map by twelvelabs_task_id AND build filename lookup
        tl_to_ours = {}
        filename_to_ours = {}
        for v in our_videos:
            tl_id = v.get('twelvelabs_task_id', '')
            if tl_id:
                tl_to_ours[tl_id] = {'video_id': v['video_id'], 'filename': v.get('filename', '')}
            if v.get('filename'):
                filename_to_ours[v['filename']] = {'video_id': v['video_id'], 'filename': v['filename']}

        # If we have unmapped 12Labs video_ids, try to resolve via 12Labs video list API
        tl_video_ids = set(clip.get('video_id', '') for clip in data.get('data', []))
        unmapped = tl_video_ids - set(tl_to_ours.keys())
        
        if unmapped:
            try:
                # Get video details from 12Labs to find filenames
                for tl_vid_id in unmapped:
                    conn2 = http.client.HTTPSConnection('api.twelvelabs.io', timeout=10)
                    conn2.request('GET', f'/v1.3/indexes/{index_id}/videos/{tl_vid_id}', headers={'x-api-key': api_key})
                    vresp = conn2.getresponse()
                    vbody = json.loads(vresp.read().decode())
                    conn2.close()
                    
                    tl_filename = vbody.get('system_metadata', {}).get('filename', '') or vbody.get('metadata', {}).get('filename', '')
                    if tl_filename and tl_filename in filename_to_ours:
                        tl_to_ours[tl_vid_id] = filename_to_ours[tl_filename]
                    elif tl_filename:
                        # Try matching without video_id prefix
                        for fn, info in filename_to_ours.items():
                            if tl_filename.endswith(fn) or fn.endswith(tl_filename):
                                tl_to_ours[tl_vid_id] = info
                                break
            except Exception as e:
                print(f"Warning: Could not resolve 12Labs video mapping: {e}")

        # Normalize and deduplicate results
        results = []
        seen = set()
        total_clips = len(data.get('data', []))
        for i, clip in enumerate(data.get('data', [])):
            tl_vid_id = clip.get('video_id', '')
            our_video = tl_to_ours.get(tl_vid_id, {})
            
            # Deduplicate by our video_id + start + end
            our_vid = our_video.get('video_id', tl_vid_id)
            dedup_key = f"{our_vid}_{clip.get('start',0)}_{clip.get('end',0)}"
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            results.append({
                'start_sec': clip.get('start', 0),
                'end_sec': clip.get('end', 0),
                'combined_score': round(1.0 - (i / max(total_clips, 1)), 4),  # Rank-based score
                'confidence': clip.get('confidence', 0),
                'video_id': our_video.get('video_id', tl_vid_id),
                'filename': our_video.get('filename', ''),
                'thumbnail_url': clip.get('thumbnail_url', ''),
                'transcription': clip.get('transcription', '')
            })

        return respond(200, {
            'results': results,
            'total': len(results),
            'latency_ms': latency_ms
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return respond(500, {'error': str(e)})

"""Face function — identity-based CRUD on face-identities table.
GET: list identities with appearance counts
PUT: rename identity
DELETE: remove identity
POST action=merge: merge identities
POST action=promote: create entity from face
"""
import json
import os
import sys
import time
sys.path.insert(0, '/opt/python')

import boto3
from decimal import Decimal
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

FACE_IDENTITIES_TABLE = os.environ.get('FACE_IDENTITIES_TABLE', '')
FACE_APPEARANCES_TABLE = os.environ.get('FACE_APPEARANCES_TABLE', '')
ENTITIES_TABLE = os.environ.get('ENTITIES_TABLE', '')
PROJECTS_TABLE = os.environ.get('PROJECTS_TABLE', '')
S3_VECTOR_BUCKET = os.environ.get('S3_VECTOR_BUCKET', '')
S3_VIDEO_BUCKET = os.environ.get('S3_VIDEO_BUCKET', '')

CORS = {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, (bytes, bytearray)):
            return None
        return super().default(obj)


def respond(status, body):
    return {'statusCode': status, 'headers': CORS, 'body': json.dumps(body, cls=DecimalEncoder)}


def lambda_handler(event, context):
    try:
        method = event.get('httpMethod', 'GET')
        qparams = event.get('queryStringParameters', {}) or {}
        body = json.loads(event.get('body', '{}') or '{}')
        project_id = qparams.get('project_id', '')

        id_table = dynamodb.Table(FACE_IDENTITIES_TABLE)
        app_table = dynamodb.Table(FACE_APPEARANCES_TABLE)

        if method == 'GET':
            rek_id = qparams.get('rekognition_face_id', '')
            video_id = qparams.get('video_id', '')
            if rek_id:
                return handle_detail(id_table, app_table, rek_id)
            if video_id:
                resp = app_table.query(KeyConditionExpression='video_id = :vid', ExpressionAttributeValues={':vid': video_id})
                return respond(200, {'appearances': resp.get('Items', [])})
            return handle_list(id_table, app_table, project_id)

        if method == 'PUT':
            return handle_update(id_table, body)

        if method == 'DELETE':
            return handle_delete(id_table, body)

        if method == 'POST':
            action = body.get('action', '')
            if action == 'merge':
                return handle_merge(id_table, app_table, body)
            if action == 'promote':
                return handle_promote(id_table, body, project_id)
            return respond(400, {'error': 'action required (merge|promote)'})

        return respond(400, {'error': 'Invalid method'})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return respond(500, {'error': str(e)})


def handle_list(id_table, app_table, project_id):
    """List face identities with appearance counts."""
    if project_id:
        resp = id_table.query(
            IndexName='project_id-index',
            KeyConditionExpression='project_id = :pid',
            ExpressionAttributeValues={':pid': project_id}
        )
    else:
        resp = id_table.scan()

    faces = []
    for item in resp.get('Items', []):
        rek_id = item['rekognition_face_id']
        # Count appearances across videos
        app_resp = app_table.scan(
            FilterExpression='rekognition_face_id = :rid',
            ExpressionAttributeValues={':rid': rek_id},
            Select='COUNT'
        )
        faces.append({
            'rekognition_face_id': rek_id,
            'name': item.get('name', ''),
            'best_frame_s3': item.get('best_frame_s3', ''),
            'quality_score': item.get('quality_score', '0'),
            'entity_id': item.get('entity_id', ''),
            'project_id': item.get('project_id', ''),
            'video_count': app_resp.get('Count', 0),
            'created_at': item.get('created_at', '')
        })

    return respond(200, {'faces': faces})


def handle_detail(id_table, app_table, rek_id):
    """Get identity + all appearances for a face."""
    identity = id_table.get_item(Key={'rekognition_face_id': rek_id}).get('Item', {})
    app_resp = app_table.scan(
        FilterExpression='rekognition_face_id = :rid',
        ExpressionAttributeValues={':rid': rek_id}
    )
    return respond(200, {'identity': identity, 'appearances': app_resp.get('Items', [])})


def handle_update(id_table, body):
    """Update a face identity — name and/or best_frame_s3."""
    rek_id = body.get('rekognition_face_id', '')
    if not rek_id:
        return respond(400, {'error': 'rekognition_face_id required'})

    update_parts = []
    values = {}
    names = {}
    if body.get('name'):
        update_parts.append('#n = :name')
        names['#n'] = 'name'
        values[':name'] = body['name']
    if body.get('best_frame_s3'):
        update_parts.append('best_frame_s3 = :bf')
        values[':bf'] = body['best_frame_s3']

    if not update_parts:
        return respond(400, {'error': 'name or best_frame_s3 required'})

    kwargs = {
        'Key': {'rekognition_face_id': rek_id},
        'UpdateExpression': 'SET ' + ', '.join(update_parts),
        'ExpressionAttributeValues': values
    }
    if names:
        kwargs['ExpressionAttributeNames'] = names
    id_table.update_item(**kwargs)
    return respond(200, {'success': True})


def handle_delete(id_table, body):
    """Delete a face identity — 1 row delete."""
    rek_id = body.get('rekognition_face_id', '')
    if not rek_id:
        return respond(400, {'error': 'rekognition_face_id required'})

    id_table.delete_item(Key={'rekognition_face_id': rek_id})
    return respond(200, {'success': True})


def handle_merge(id_table, app_table, body):
    """Merge face identities: keep target, reassign source appearances, delete sources."""
    target_id = body.get('target_rekognition_face_id', '')
    source_ids = body.get('source_rekognition_face_ids', [])
    name = body.get('name', '')

    if not target_id or not source_ids:
        return respond(400, {'error': 'target and source rekognition_face_ids required'})

    # Rename target if name provided
    if name:
        id_table.update_item(
            Key={'rekognition_face_id': target_id},
            UpdateExpression='SET #n = :name',
            ExpressionAttributeNames={'#n': 'name'},
            ExpressionAttributeValues={':name': name}
        )

    # For each source: reassign appearances to target, delete source identity
    for src_id in source_ids:
        if src_id == target_id:
            continue
        # Find all appearances of source
        app_resp = app_table.scan(
            FilterExpression='rekognition_face_id = :rid',
            ExpressionAttributeValues={':rid': src_id}
        )
        for app in app_resp.get('Items', []):
            # Delete old appearance
            app_table.delete_item(Key={'video_id': app['video_id'], 'rekognition_face_id': src_id})
            # Create new appearance under target (keep original crop_s3)
            app['rekognition_face_id'] = target_id
            app_table.put_item(Item=app)

        # Delete source identity
        id_table.delete_item(Key={'rekognition_face_id': src_id})

    return respond(200, {'success': True})


def handle_promote(id_table, body, project_id):
    """Promote face to entity: generate embedding, create entity, link."""
    rek_id = body.get('rekognition_face_id', '')
    if not rek_id:
        return respond(400, {'error': 'rekognition_face_id required'})

    identity = id_table.get_item(Key={'rekognition_face_id': rek_id}).get('Item', {})
    if not identity:
        return respond(404, {'error': 'Face identity not found'})

    name = identity.get('name', '') or f"person_{rek_id[:8]}"
    face_s3 = identity.get('best_frame_s3', '')
    pid = project_id or identity.get('project_id', '')

    # Determine embedding model from project
    proj = dynamodb.Table(PROJECTS_TABLE).get_item(Key={'project_id': pid}).get('Item', {}) if pid else {}
    model = proj.get('embedding_model', 'marengo')

    # Generate embedding from face crop
    embedding = None
    try:
        if face_s3:
            if model == 'nova-mme':
                from nova_embeddings import generate_image_embedding_nova
                embedding = generate_image_embedding_nova(face_s3, purpose='GENERIC_INDEX')
            else:
                from bedrock_embeddings import generate_face_embedding
                embedding = generate_face_embedding(face_s3)
    except Exception as e:
        print(f"Embedding generation failed: {e}")

    # Store in entity vector index
    if embedding and S3_VECTOR_BUCKET:
        try:
            s3vectors = boto3.client('s3vectors', region_name=os.environ.get('AWS_REGION', 'us-east-1'))
            proj = dynamodb.Table(PROJECTS_TABLE).get_item(Key={'project_id': pid}).get('Item', {}) if pid else {}
            model = proj.get('embedding_model', 'nova-mme')
            prefix = 'nova' if model == 'nova-mme' else 'marengo'
            entity_index = f'{prefix}-entity-{pid}' if pid else f'{prefix}-entity-index'

            s3vectors.put_vectors(
                vectorBucketName=S3_VECTOR_BUCKET,
                indexName=entity_index,
                vectors=[{
                    'key': rek_id,
                    'data': {'float32': [float(v) for v in embedding]},
                    'metadata': {'rekognition_face_id': rek_id, 'name': name}
                }]
            )
            print(f"Stored {len(embedding)}d embedding for entity {name}")
        except Exception as e:
            print(f"Vector storage failed: {e}")

    # Create entity
    entity_id = f"entity_{name.lower().replace(' ', '_')}_{int(time.time())}"
    ent_table = dynamodb.Table(ENTITIES_TABLE)
    entity_item = {
        'entity_id': entity_id,
        'name': name,
        'description': '',
        'thumbnail_s3': face_s3,
        'project_id': pid,
        'rekognition_face_id': rek_id,
        'created_at': datetime.utcnow().isoformat()
    }
    if embedding:
        import struct
        entity_item['embedding'] = struct.pack(f'{len(embedding)}f', *embedding)
    ent_table.put_item(Item=entity_item)

    # Sync to 12Labs SaaS if enabled
    tl_entity_id = None
    if pid:
        try:
            proj = dynamodb.Table(PROJECTS_TABLE).get_item(Key={'project_id': pid}).get('Item', {})
            if proj.get('saas_enabled') and proj.get('twelvelabs_api_key') and face_s3:
                from twelvelabs_helper import upload_asset_from_url, create_entity as tl_create_entity, get_or_create_collection
                api_key = proj['twelvelabs_api_key']
                tl_collection_id = proj.get('twelvelabs_collection_id')
                if not tl_collection_id:
                    tl_collection_id = get_or_create_collection(api_key, proj.get('name', pid))
                    if tl_collection_id:
                        dynamodb.Table(PROJECTS_TABLE).update_item(
                            Key={'project_id': pid},
                            UpdateExpression='SET twelvelabs_collection_id = :cid',
                            ExpressionAttributeValues={':cid': tl_collection_id}
                        )
                if tl_collection_id:
                    bucket = face_s3.replace('s3://', '').split('/')[0]
                    key = '/'.join(face_s3.replace('s3://', '').split('/')[1:])
                    presigned = s3.generate_presigned_url('get_object', Params={'Bucket': bucket, 'Key': key}, ExpiresIn=3600)
                    asset_id = upload_asset_from_url(api_key, presigned)
                    if asset_id:
                        tl_entity_id = tl_create_entity(api_key, tl_collection_id, name, [asset_id])
                        if tl_entity_id:
                            ent_table.update_item(
                                Key={'entity_id': entity_id},
                                UpdateExpression='SET twelvelabs_entity_id = :tid, twelvelabs_collection_id = :cid',
                                ExpressionAttributeValues={':tid': tl_entity_id, ':cid': tl_collection_id}
                            )
                            print(f"12Labs entity created: {tl_entity_id}")
        except Exception as e:
            print(f"12Labs sync skipped: {e}")

    return respond(201, {'success': True, 'entity_id': entity_id, 'name': name})

"""SaaS Index Lambda - submits video to 12Labs SaaS API.
Fire-and-forget. Only runs if project has saas_enabled=True.
"""
import json
import os
import sys
import time
import http.client
sys.path.insert(0, '/opt/python')

import boto3

aws_region = os.environ.get('AWS_REGION', 'us-east-1')
s3_client = boto3.client('s3', region_name=aws_region)
dynamodb = boto3.resource('dynamodb', region_name=aws_region)

VIDEOS_TABLE = os.environ.get('VIDEOS_TABLE', '')


def lambda_handler(event, context):
    if not event.get('saas_enabled'):
        return {'skipped': True}

    video_id = event['video_id']
    s3_uri = event['s3_uri']
    saas_config = event.get('saas_config', {})
    api_key = saas_config.get('api_key', '')
    index_id = saas_config.get('index_id', '')

    if not api_key or not index_id:
        return {'skipped': True, 'reason': 'No SaaS credentials'}

    # Check if already indexed
    table = dynamodb.Table(VIDEOS_TABLE)
    record = table.get_item(Key={'video_id': video_id}).get('Item', {})
    if record.get('twelvelabs_task_id'):
        return {'skipped': True, 'reason': 'Already indexed'}

    # Generate presigned URL
    bucket, key = s3_uri.replace('s3://', '').split('/', 1)
    download_url = s3_client.generate_presigned_url('get_object', Params={'Bucket': bucket, 'Key': key}, ExpiresIn=3600)

    # Submit to 12Labs
    boundary = f'----Boundary{int(time.time() * 1000)}'
    parts = []
    for name, value in [('index_id', index_id), ('video_url', download_url)]:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}')
    body_data = '\r\n'.join(parts) + f'\r\n--{boundary}--\r\n'

    conn = http.client.HTTPSConnection('api.twelvelabs.io', timeout=30)
    conn.request('POST', '/v1.3/tasks', body=body_data.encode('utf-8'), headers={
        'x-api-key': api_key,
        'Content-Type': f'multipart/form-data; boundary={boundary}'
    })
    resp = conn.getresponse()
    resp_body = resp.read().decode()
    conn.close()

    print(f"12Labs SaaS: status={resp.status}")

    # Store task ID
    try:
        data = json.loads(resp_body)
        task_id = data.get('_id', '')
        if task_id:
            table.update_item(
                Key={'video_id': video_id},
                UpdateExpression='SET twelvelabs_task_id = :tid',
                ExpressionAttributeValues={':tid': task_id}
            )
    except:
        pass

    return {'submitted': True, 'status': resp.status}

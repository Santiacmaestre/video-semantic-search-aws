"""Generate video embeddings using TwelveLabs Marengo 3.0 via Bedrock.

Single async API call produces separate visual, audio, and transcription
embeddings (512d each) per clip, then stores them in S3 Vectors.
Segment metadata is saved to S3 to avoid Step Functions payload limits.
"""
import json
import os
import sys
sys.path.insert(0, '/opt/python')

import boto3
from twelvelabs_embeddings import generate_video_embeddings
from vector_store import store_video_embeddings

AWS_ACCOUNT_ID = os.environ.get('AWS_ACCOUNT_ID', '')
S3_VIDEO_BUCKET = os.environ.get('S3_VIDEO_BUCKET', '')
s3 = boto3.client('s3', region_name=os.environ.get('AWS_REGION', 'us-east-1'))


def lambda_handler(event, context):
    """Embed full video via Marengo and store vectors in S3 Vectors."""
    video_id = event['video_id']
    project_id = event.get('project_id', '')
    filename = event.get('filename', '')
    s3_uri = event.get('s3_uri', '')

    segments = generate_video_embeddings(s3_uri, AWS_ACCOUNT_ID)

    store_video_embeddings(video_id, filename, segments, project_id)

    # Save segment metadata to S3 (avoids Step Functions 256KB payload limit)
    seg_meta = [
        {'segment_index': s['segment_index'], 'start_sec': s['start_sec'], 'end_sec': s['end_sec'],
         'has_visual': 'visual_emb' in s, 'has_audio': 'audio_emb' in s,
         'has_transcription': 'transcription_emb' in s}
        for s in segments
    ]
    segments_key = f"metadata/{video_id}/segments.json"
    s3.put_object(Bucket=S3_VIDEO_BUCKET, Key=segments_key,
                  Body=json.dumps(seg_meta), ContentType='application/json')

    return {
        'segments_s3_key': segments_key,
        'segment_count': len(segments),
    }
